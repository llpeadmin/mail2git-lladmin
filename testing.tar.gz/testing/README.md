ToDo nach cluster-install

 - Cluster Update durchfuehren auf gewuenschte OCP Version

 - Default worker Machineset loeschen: 
```
   oc get machineset -n openshift-machine-api
   oc delete machineset -n openshift-machine-api <machineset>
```






Cluster neu beginnen

  - ArgoCD Applikationen und OCP Cluster loeschen
```
argocd cluster rm default/api-hd6-llsuva-test:6443/kube:admin
for APP in $(argocd app list | grep api.hd6.llsuva | awk '{print $1}'); do argocd app delete ${APP} -y ;done
```

 - GIT Manifeste loeschen
```
rm -rf plattform/clusterresourcequotas/request-storage/overlays/hd6
rm -rf plattform/kubeletconfigs/overlays/hd6
rm -rf plattform/machinesets/hd6
```

git push
