Pro Cluster ein eigener Folder mit base template und overlay, da sich jeder Cluster in den Einstellungen stark unterscheidet. Ich denke sonst wuerden die Overlays sehr unuebersichtlich
