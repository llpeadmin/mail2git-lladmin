Create MachineConfig from butane files, see https://docs.openshift.com/container-platform/4.12/installing/install_config/installing-customizing.html#installation-special-config-butane-create_installing-customizing

Syntax:
```
butane 99-worker-custom.bu -o ./99-worker-custom.yaml
```
