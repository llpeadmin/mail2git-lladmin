#!/bin/bash
#

################################################################################
#
# 14.12.2023 Erstellung
#

DEFAULTBASEDOMAIN="llsuva.test"
ARGOCDURL="argocd-sample-server-openshift-operators.apps.hd6mgmt.llsuva.test"


MSBASEFOLDER="./plattform/machinesets"
MSTEMPLATEFOLDER="${MSBASEFOLDER}/TEMPLATE"
KUBELETCONFIGBASEFOLDER="./plattform/kubeletconfigs/overlays"
KUBELETCONFIGTEMPLATEFOLDER="${KUBELETCONFIGBASEFOLDER}/TEMPLATE"
CRQBASEFOLDER="./plattform/clusterresourcequotas/request-storage/overlays"
CRQTEMPLATEFOLDER="${CRQBASEFOLDER}/TEMPLATE"
APISERVERBASEFOLDER="./plattform/apiserver"
APISERVERTEMPLATEFOLDER="${APISERVERBASEFOLDER}/TEMPLATE"
ARGOBASEFOLDER="./argocd/applications"
ARGOTEMPLATEFOLDER="${ARGOBASEFOLDER}/TEMPLATE"
# Check ob files da sind
if [ ! -d ${MSTEMPLATEFILE} ]
then
 echo "Folder \"${MSTEMPLATEFILE}\" nicht gefunden - breche ab"
 exit 1
elif [ ! -d ${ARGOTEMPLATEFOLDER} ]
then
  echo "Folder \"${ARGOTEMPLATEFOLDER}\" nicht gefunden - breche ab"
  exit 1
fi

# Lese Infos von User
CLUSTER=""
read -p "Cluster: " CLUSTER

CLUSTERADMINDEFAULT=kubeadmin
CLUSTERADMIN=""
read -p "Cluster Admin [${CLUSTERADMINDEFAULT}]: " CLUSTERADMIN
CLUSTERADMIN=${CLUSTERADMIN:-$CLUSTERADMINDEFAULT}

read -p "Base Domain: [$DEFAULTBASEDOMAIN]: " BASEDOMAIN
BASEDOMAIN=${BASEDOMAIN:-$DEFAULTBASEDOMAIN}

oc login --insecure-skip-tls-verify=false https://api.${CLUSTER}.${BASEDOMAIN}:6443 -u ${CLUSTERADMIN} #-p ${PW}
RC=$?
if [ $RC -ne 0 ]
then
  echo "oc login failed - RC: ${RC} - breche ab"
  exit 1
fi

MSWORKER=$(oc get machineset -n openshift-machine-api $(oc get machineset -A | grep worker | awk '{print $2}') -o json)
echo "$MSWORKER" | grep -q '"kind": "MachineSet"'
RC=$?
if [ $RC -ne 0 ]
then
  echo "Kann worker machineset nicht auslesen - breche ab"
  exit 1
fi

INFRAID=$(oc get -o jsonpath='{.status.infrastructureName}{"\n"}' infrastructure cluster | awk -F\- '{print $2}')
if [ -z $INFRAID ]
then
  echo "Kann Infra ID nicht auslesen - brech ab"
  exit 1
fi

TEMPLATE=$(echo "${MSWORKER}" | jq -r '.spec.template.spec.providerSpec.value.template')
NETWORKNAME=$(echo "${MSWORKER}" | jq -r '.spec.template.spec.providerSpec.value.network.devices[].networkName')
DATACENTER=$(echo "${MSWORKER}" | jq -r '.spec.template.spec.providerSpec.value.workspace.datacenter')
DATASTORE=$(echo "${MSWORKER}" | jq -r '.spec.template.spec.providerSpec.value.workspace.datastore')
FOLDER=$(echo "${MSWORKER}" | jq -r '.spec.template.spec.providerSpec.value.workspace.folder')
RESOURCEPOOL=$(echo "${MSWORKER}" | jq -r '.spec.template.spec.providerSpec.value.workspace.resourcePool')
VCENTER=$(echo "${MSWORKER}" | jq -r '.spec.template.spec.providerSpec.value.workspace.server')

echo "Erstelle MachineSet Manifest Files"
rm -rf ${MSBASEFOLDER}/${CLUSTER}
cp -r ${MSTEMPLATEFOLDER} ${MSBASEFOLDER}/${CLUSTER}

WORKERCPUDEFAULT="4"
WORKERCPU=""
read -p "Anzahl CPU Cores pro Worker [$WORKERCPUDEFAULT]: " WORKERCPU
WORKERCPU=${WORKERCPU:-$WORKERCPUDEFAULT}

WORKERMEMORYDEFAULT="32768"
WORKERMEMORY=""
read -p "MEMORY pro Worker in MiB [$WORKERMEMORYDEFAULT]: " WORKERMEMORY
WORKERMEMORY=${WORKERMEMORY:-$WORKERMEMORYDEFAULT}

echo "Passe File an: ${MSBASEFOLDER}/${CLUSTER}/base/template.yaml"
sed -i "s?{{CLUSTER}}?${CLUSTER}?g" ${MSBASEFOLDER}/${CLUSTER}/base/template.yaml
sed -i "s?{{PREFIX}}?${INFRAID}?g" ${MSBASEFOLDER}/${CLUSTER}/base/template.yaml
sed -i "s?{{TEMPLATE}}?${TEMPLATE}?g" ${MSBASEFOLDER}/${CLUSTER}/base/template.yaml
sed -i "s?{{NETWORKNAME}}?${NETWORKNAME}?g" ${MSBASEFOLDER}/${CLUSTER}/base/template.yaml
sed -i "s?{{DATACENTER}}?${DATACENTER}?g" ${MSBASEFOLDER}/${CLUSTER}/base/template.yaml
sed -i "s?{{DATASTORE}}?${DATASTORE}?g" ${MSBASEFOLDER}/${CLUSTER}/base/template.yaml
sed -i "s?{{FOLDER}}?${FOLDER}?g" ${MSBASEFOLDER}/${CLUSTER}/base/template.yaml
sed -i "s?{{RESOURCEPOOL}}?${RESOURCEPOOL}?g" ${MSBASEFOLDER}/${CLUSTER}/base/template.yaml
sed -i "s?{{VCENTER}}?${VCENTER}?g" ${MSBASEFOLDER}/${CLUSTER}/base/template.yaml

echo "Passe File an: ${MSBASEFOLDER}/${CLUSTER}/overlays/worker-0/worker-0.yaml"
sed -i "s?{{CLUSTER}}?${CLUSTER}?g" ${MSBASEFOLDER}/${CLUSTER}/overlays/worker-0/worker-0.yaml
sed -i "s?{{PREFIX}}?${INFRAID}?g" ${MSBASEFOLDER}/${CLUSTER}/overlays/worker-0/worker-0.yaml
sed -i "s?{{WORKERMEMORY}}?${WORKERMEMORY}?g" ${MSBASEFOLDER}/${CLUSTER}/overlays/worker-0/worker-0.yaml
sed -i "s?{{WORKERCPU}}?${WORKERCPU}?g" ${MSBASEFOLDER}/${CLUSTER}/overlays/worker-0/worker-0.yaml

echo "Passe File an: ${MSBASEFOLDER}/${CLUSTER}/overlays/worker-1/worker-1.yaml"
sed -i "s?{{CLUSTER}}?${CLUSTER}?g" ${MSBASEFOLDER}/${CLUSTER}/overlays/worker-1/worker-1.yaml
sed -i "s?{{PREFIX}}?${INFRAID}?g" ${MSBASEFOLDER}/${CLUSTER}/overlays/worker-1/worker-1.yaml
sed -i "s?{{WORKERMEMORY}}?${WORKERMEMORY}?g" ${MSBASEFOLDER}/${CLUSTER}/overlays/worker-1/worker-1.yaml
sed -i "s?{{WORKERCPU}}?${WORKERCPU}?g" ${MSBASEFOLDER}/${CLUSTER}/overlays/worker-1/worker-1.yaml

echo "Passe File an: ${MSBASEFOLDER}/${CLUSTER}/overlays/worker-2/worker-2.yaml"
sed -i "s?{{CLUSTER}}?${CLUSTER}?g" ${MSBASEFOLDER}/${CLUSTER}/overlays/worker-2/worker-2.yaml
sed -i "s?{{PREFIX}}?${INFRAID}?g" ${MSBASEFOLDER}/${CLUSTER}/overlays/worker-2/worker-2.yaml
sed -i "s?{{WORKERMEMORY}}?${WORKERMEMORY}?g" ${MSBASEFOLDER}/${CLUSTER}/overlays/worker-2/worker-2.yaml
sed -i "s?{{WORKERCPU}}?${WORKERCPU}?g" ${MSBASEFOLDER}/${CLUSTER}/overlays/worker-2/worker-2.yaml

echo "Passe File an: ${MSBASEFOLDER}/${CLUSTER}/overlays/worker-3/worker-3.yaml"
sed -i "s?{{CLUSTER}}?${CLUSTER}?g" ${MSBASEFOLDER}/${CLUSTER}/overlays/worker-3/worker-3.yaml
sed -i "s?{{PREFIX}}?${INFRAID}?g" ${MSBASEFOLDER}/${CLUSTER}/overlays/worker-3/worker-3.yaml
sed -i "s?{{WORKERMEMORY}}?${WORKERMEMORY}?g" ${MSBASEFOLDER}/${CLUSTER}/overlays/worker-3/worker-3.yaml
sed -i "s?{{WORKERCPU}}?${WORKERCPU}?g" ${MSBASEFOLDER}/${CLUSTER}/overlays/worker-3/worker-3.yaml


echo "Erstelle KubeletConfig Manifest Files"
KUBELETCPUDEFAULT="500m"
KUBELETCPU=""
read -p "Kubelet SystemReserved CPU [$KUBELETCPUDEFAULT]: " KUBELETCPU
KUBELETCPU=${KUBELETCPU:-$KUBELETCPUDEFAULT}

KUBELETMEMORYDEFAULT="4Gi"
KUBELETMEMORY=""
read -p "Kubelet SystemReserved MEMORY [$KUBELETMEMORYDEFAULT]: " KUBELETMEMORY
KUBELETMEMORY=${KUBELETMEMORY:-$KUBELETMEMORYDEFAULT}

rm -rf ${KUBELETCONFIGBASEFOLDER}/${CLUSTER}
cp -r ${KUBELETCONFIGTEMPLATEFOLDER} ${KUBELETCONFIGBASEFOLDER}/${CLUSTER}

echo "Passe File an: ${KUBELETCONFIGBASEFOLDER}/${CLUSTER}/master.yaml"
sed -i "s?{{KUBELETCPU}}?${KUBELETCPU}?g" ${KUBELETCONFIGBASEFOLDER}/${CLUSTER}/master.yaml
sed -i "s?{{KUBELETMEMORY}}?${KUBELETMEMORY}?g" ${KUBELETCONFIGBASEFOLDER}/${CLUSTER}/master.yaml

echo "Passe File an: ${KUBELETCONFIGBASEFOLDER}/${CLUSTER}/worker.yaml"
sed -i "s?{{KUBELETCPU}}?${KUBELETCPU}?g" ${KUBELETCONFIGBASEFOLDER}/${CLUSTER}/worker.yaml
sed -i "s?{{KUBELETMEMORY}}?${KUBELETMEMORY}?g" ${KUBELETCONFIGBASEFOLDER}/${CLUSTER}/worker.yaml



echo "Erstelle ClusterResourceQuota Manifest Files"
THINCSIQUOTADEFAULT="1Ti"
THINCSIQUOTA=""
read -p "thin-csi ClusterResourceQuota [$THINCSIQUOTADEFAULT]: " THINCSIQUOTA
THINCSIQUOTA=${THINCSIQUOTA:-$THINCSIQUOTADEFAULT}

HNASCSIQUOTADEFAULT="5Ti"
HNASCSIQUOTA=""
read -p "hnas-csi ClusterResourceQuota [$HNASCSIQUOTADEFAULT]: " HNASCSIQUOTA
HNASCSIQUOTA=${HNASCSIQUOTA:-$HNASCSIQUOTADEFAULT}

rm -rf ${CRQBASEFOLDER}/${CLUSTER}
cp -r ${CRQTEMPLATEFOLDER} ${CRQBASEFOLDER}/${CLUSTER}

echo "Passe File an: ${CRQBASEFOLDER}/${CLUSTER}/master.yaml"
sed -i "s?{{THINCSIQUOTA}}?${THINCSIQUOTA}?g" ${CRQBASEFOLDER}/${CLUSTER}/suva-csi-request-storage.yaml
sed -i "s?{{HNASCSIQUOTA}}?${HNASCSIQUOTA}?g" ${CRQBASEFOLDER}/${CLUSTER}/suva-csi-request-storage.yaml


echo "Erstelle ApiServer Manifest Files"
rm -rf ${APISERVERBASEFOLDER}/${CLUSTER}
cp -r ${APISERVERTEMPLATEFOLDER}/${CLUSTER}
echo "Passe File an: ${APISERVERBASEFOLDER}/${CLUSTER}/base/cluster.yaml"
sed -i "s?{{CLUSTER}}?${CLUSTER}?g" ${APISERVERBASEFOLDER}/${CLUSTER}/base/cluster.yaml




# ArgoCD Application Manifests erstellen
echo "Erstelle ArgoCD apps Application Manifest Files"
rm -rf ${ARGOBASEFOLDER}/${CLUSTER}
cp -r ${ARGOTEMPLATEFOLDER} ${ARGOBASEFOLDER}/${CLUSTER}
# ArgoCD app-of-apps Manifest
echo "Passe File an: ${ARGOBASEFOLDER}/${CLUSTER}/${FILE}/app-of-apps.yaml"
sed -i "s/{{CLUSTER}}/${CLUSTER}/g" ${ARGOBASEFOLDER}/${CLUSTER}/app-of-apps.yaml
# ArgoCD Apps Manifeste
for FILE in $(ls ${ARGOBASEFOLDER}/${CLUSTER}/apps)
do
  echo "Passe File an: ${ARGOBASEFOLDER}/${CLUSTER}/apps/${FILE}"
  sed -i "s/{{CLUSTER}}/${CLUSTER}/g" ${ARGOBASEFOLDER}/${CLUSTER}/apps/${FILE}
done


# Manifeste ins GIT Pushen
PUSHTOGIT=""
echo "DRY-RUN von \"git add --all\""
git add --all --dry-run
read -p "Sollen die obigen Files ins GIT pushed werden? [y/n] " PUSHTOGIT
case ${PUSHTOGIT} in
  y|Y|j|J)
    echo "git add --all"
    git add --all
    echo "git commit --all -m \"$(whoami) - by Script create-manifests.sh\""
    git commit --all -m "$(whoami) - by Script create-manifests.sh"
    echo "git push"
    git push
    ;;
  *)
    echo "Pushe files nicht ins GIT - skip"
    ;;
esac

# OpenShift Cluster an ArgoCD anbinden
CONNECTARGO=""
read -p "OCP Cluster ${CLUSTER} an ArgoCD anbinden (ArgoCD Applikationen werden noch nicht erstellt)? [y/n] " CONNECTARGO
case ${CONNECTARGO} in 
  y|Y|j|J)
    echo "Anmelden an ArgoCD: argocd login --sso ${ARGOCDURL}"
    echo "Bitte OpenShift Login Credentials im Browserfenster eingeben"
    argocd login --insecure --sso ${ARGOCDURL}
    ARGOCLUSTERADDNAME=$(argocd cluster add 2>/dev/null | grep '*' | awk '{print $2}')
    RC=$?
    if [ ! -z $ARGOCLUSTERADDNAME ] && [ $RC -eq 0 ]
    then
      echo "argocd cluster add ${ARGOCLUSTERADDNAME}"
      argocd cluster add ${ARGOCLUSTERADDNAME} -y --upsert
      RC=$?
      if [ $RC -ne 0 ]
      then
        echo "Fehler beim anbinden des OCP Clusters an ArgoCD"
        NOARGOCLUSTERCONNECT="true"
      fi
    else
      echo "Fehler beim auslesen des Cluster Names - skip OCP Cluster an ArgoCD anbinden"
      NOARGOCLUSTERCONNECT="true"
    fi
    ;;
  *)
    echo "Binde Cluster ${CLUSTER} NICHT an ArgoCD an - skip"
    NOARGOCLUSTERCONNECT="true"
    ;;
esac

# ArgoCD Applikationen erstellen
ADDARGOAPPS=""
read -p "ArgoCD Applikationen fuer Cluster ${CLUSTER} erstellen (Auto Sync auf den Cluster ist deaktiviert)? [y/n] " ADDARGOAPPS
case ${ADDARGOAPPS} in
  y|Y|j|J)
    echo "Erstelle Applikationen fuer Cluster ${CLUSTER} in ArgoCD"
    if [ "${NOARGOCLUSTERCONNECT}" == "true" ]
    then
      argocd login --insecure --sso ${ARGOCDURL}
      RC=$?
      if [ $RC -ne 0 ]
      then
        echo "Fehler beim login an argocd, kann ArgoCD Applikationen nicht erstellen - breche ab"
        exit 1
      fi
    fi
    echo "Erstelle ArgoCD Applikation aus Manifest \"${ARGOBASEFOLDER}/${CLUSTER}/app-of-apps.yaml\""
    argocd app create --upsert -f ${ARGOBASEFOLDER}/${CLUSTER}/app-of-apps.yaml
    #for FILE in $(ls ${ARGOBASEFOLDER}/${CLUSTER})
    #do
    #  echo "Erstelle ArgoCD Applikation aus Manifest \"${ARGOBASEFOLDER}/${CLUSTER}/${FILE}\""
    #  argocd app create --upsert -f ${ARGOBASEFOLDER}/${CLUSTER}/${FILE}
    #done
    ;;
  *)
    echo "Erstelle Applikation in ArgoCD NICHT - skip"
    ;;
esac


