ArgoCD CLI Login
```
argocd login --sso argocd-sample-server-openshift-operators.apps.hd6mgmt.llsuva.test
```

OpenShift Cluster unter die Verwaltung von OpenShift stellen (cluster add)
 1. Login an OpenShift Cluster API mit ClusterAdmin rechten 
```
oc login https://api.<clustername>.llsuva.test:6443 -u kubeadmin
``` 
 2. Namen des Clusters anzeigen
```
argocd cluster add
```
 3. OpenShift Cluster zu ArgoCD hinzufuegen
```
argocd cluster add <name des clusters>

Bsp: argocd cluster add default/api-hd6mgmt-llsuva-test:6443/kubeadmin
```


Apps exportieren Bsp:
```
 CLUSTER=hd6mgmt; for APP in $(argocd app list -o name | grep ${CLUSTER}) ; do argocd app get ${APP} -o yaml | kubectl-neat > ${CLUSTER}/$(echo ${APP} | awk -F/ '{print $2}'); done
```

Apps des neuen Cluster Importieren Bsp:
```  
  TEMPLATECLUSTER=hd6mgmt
  NEWCLUSTER=hd6

  mkdir -p ${NEWCLUSTER}
  
  for FILE in $(ls ${TEMPLATECLUSTER})
  do 
    NEWFILE=$(echo ${FILE} | sed "s/${TEMPLATECLUSTER}/${NEWCLUSTER}/g")
    cp ${TEMPLATECLUSTER}/${FILE} ${NEWCLUSTER}/${NEWFILE}
    sed -i "s/${TEMPLATECLUSTER}/${NEWCLUSTER}/g" ${NEWCLUSTER}/${NEWFILE}
  done

  for FILE in $(ls ${NEWCLUSTER})
  do  
    argocd app create -f ${NEWCLUSTER}/${FILE}
  done
```
